#define RAD_DEG(x) (x*atan(1.0)/45.0)
#define DEG_RAD(x) (x*45.0/atan(1.0))
