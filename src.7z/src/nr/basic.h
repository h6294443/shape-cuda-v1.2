#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "../nr/nr.h"
