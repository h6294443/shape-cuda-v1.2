/* performs a dot product */

#include "basic.h"

double dot( double x[3], double y[3])
{
  return x[0]*y[0]+x[1]*y[1]+x[2]*y[2];
}
