#include "../shape/shape-cuda.h"

double *fparstep;
double *fpartol;
double *fparabstol;
double **fpntr;
int *fpartype;

